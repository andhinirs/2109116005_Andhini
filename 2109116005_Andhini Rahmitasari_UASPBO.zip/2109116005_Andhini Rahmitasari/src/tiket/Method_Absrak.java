package tiket;


public abstract class Method_Absrak {
    public abstract String pesan();
    public abstract String peringatantambah();
    public abstract String peringatanhapus();
    public abstract String peringatanupdate();
    
}
