package tiket;

public interface Method_CRUD {
    
    public void tambah();
    public void hapus();
    public void update();
}
